import { Router, Request, Response, NextFunction } from "express";
import { z } from "zod";
import { TrafficService } from "../application/trafficService";
import { createJunctionSchema, sensorEventSchema, commandSchema, controllerEventSchema } from "./validation";

export function createRouter(service: TrafficService) {
  const router = Router();

  const ok = (res: Response, body: unknown, status = 200) => res.status(status).json(body);

  router.get("/junctions", (_req, res) => ok(res, service.listJunctions()));

  router.get("/junctions/:id", (req, res, next) => {
    try { return ok(res, service.getJunction(req.params.id)); } catch (e) { return next(e); }
  });

  router.post("/junctions", (req, res, next) => {
    try {
      const body = createJunctionSchema.parse(req.body);
      return ok(res, service.createJunction(body.id, body.name), 201);
    } catch (e) { return next(e); }
  });

  router.get("/junctions/:id/status", (req, res, next) => {
    try { return ok(res, service.status(req.params.id)); } catch (e) { return next(e); }
  });

  router.post("/sensor-events", (req, res, next) => {
    try {
      const event = sensorEventSchema.parse(req.body);
      return ok(res, service.sensorEvent(event), 202);
    } catch (e) { return next(e); }
  });

  router.post("/junctions/:id/commands", (req, res, next) => {
    try {
      const body = commandSchema.parse(req.body);

      if (body.command === "REQUEST_PHASE") {
        return ok(res, service.manual(req.params.id, body.phase), 202);
      }

      return ok(res, service.returnAutomatic(req.params.id));
    } catch (e) { return next(e); }
  });

  router.post("/controller-events", (req, res, next) => {
    try {
      const body = controllerEventSchema.parse(req.body);
      return ok(res, service.controllerEvent(body.command_id, body.event_type));
    } catch (e) { return next(e); }
  });

  router.get("/junctions/:id/history", (req, res, next) => {
    try {
      const limit = Math.min(Number(req.query.limit ?? 100), 500);
      if (!Number.isInteger(limit) || limit < 1) throw new Error("INVALID_LIMIT");
      return ok(res, service.history(req.params.id, limit));
    } catch (e) { return next(e); }
  });

  return router;
}

export function errorHandler(err: unknown, _req: Request, res: Response, _next: NextFunction) {
  if (err instanceof z.ZodError) {
    return res.status(400).json({ error: "VALIDATION_ERROR", details: err.flatten() });
  }

  const message = err instanceof Error ? err.message : "INTERNAL_ERROR";
  const map: Record<string, number> = {
    JUNCTION_NOT_FOUND: 404,
    JUNCTION_EXISTS: 409,
    COMMAND_NOT_FOUND: 404,
    INVALID_LIMIT: 400
  };

  return res.status(map[message] ?? 500).json({ error: message });
}
