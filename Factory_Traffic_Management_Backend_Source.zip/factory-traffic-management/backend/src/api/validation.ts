import { z } from "zod";

export const createJunctionSchema = z.object({
  id: z.string().min(1).max(50),
  name: z.string().min(1).max(100)
});

export const sensorEventSchema = z.object({
  event_id: z.string().min(1),
  junction_id: z.string().min(1),
  direction: z.enum(["NORTH", "SOUTH", "EAST", "WEST"]),
  event_type: z.enum(["ARRIVAL", "CLEAR"]),
  vehicle_id: z.string().min(1),
  vehicle_type: z.enum(["FORKLIFT", "TRUCK", "EMPLOYEE_VEHICLE", "EMERGENCY"]),
  sequence_no: z.number().int().nonnegative(),
  timestamp: z.string().datetime()
});

export const commandSchema = z.discriminatedUnion("command", [
  z.object({ command: z.literal("REQUEST_PHASE"), phase: z.enum(["NORTH_SOUTH", "EAST_WEST"]) }),
  z.object({ command: z.literal("RETURN_AUTOMATIC") }),
  z.object({ command: z.literal("EMERGENCY_CLEAR") })
]);

export const controllerEventSchema = z.object({
  command_id: z.string().min(1),
  event_type: z.enum(["ACK", "NACK", "TIMEOUT", "OFFLINE", "ONLINE"]),
  junction_id: z.string().min(1).optional()
});
