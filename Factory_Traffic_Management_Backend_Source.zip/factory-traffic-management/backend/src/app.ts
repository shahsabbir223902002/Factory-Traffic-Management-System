import express from "express";
import cors from "cors";
import { JunctionRepository } from "./infrastructure/junctionRepository";
import { EventRepository } from "./infrastructure/eventRepository";
import { RestControllerSimulator } from "./infrastructure/controller";
import { TrafficService } from "./application/trafficService";
import { createRouter, errorHandler } from "./api/routes";

export function createApp() {
  const app = express();

  app.use(cors());
  app.use(express.json());

  const junctions = new JunctionRepository();
  const events = new EventRepository();
  const controller = new RestControllerSimulator();
  const service = new TrafficService(junctions, events, controller);

  app.get("/health", (_req, res) => res.json({ status: "ok" }));
  app.use("/api", createRouter(service));
  app.use(errorHandler);

  return app;
}
