import { EventRepository } from "../infrastructure/eventRepository";
import { JunctionRepository } from "../infrastructure/junctionRepository";
import { ControllerPort } from "../infrastructure/controller";
import { audit } from "../infrastructure/database";
import { SensorEvent, Phase } from "../domain/types";
import { TrafficEngine } from "../domain/engine";

const engines = new Map<string, TrafficEngine>();

function engineFor(junctionId: string): TrafficEngine {
  let engine = engines.get(junctionId);
  if (!engine) {
    engine = new TrafficEngine();
    engines.set(junctionId, engine);
  }
  return engine;
}

export class TrafficService {
  constructor(
    private readonly junctions: JunctionRepository,
    private readonly events: EventRepository,
    private readonly controller: ControllerPort
  ) {}

  createJunction(id: string, name: string) {
    if (this.junctions.exists(id)) throw new Error("JUNCTION_EXISTS");
    this.junctions.create(id, name);
    audit(id, "JUNCTION_CREATED", `Junction ${id} created`);
    return this.junctions.get(id);
  }

  listJunctions() {
    return this.junctions.list();
  }

  getJunction(id: string) {
    const result = this.junctions.get(id);
    if (!result) throw new Error("JUNCTION_NOT_FOUND");
    return result;
  }

  status(id: string) {
    const result = this.junctions.status(id);
    if (!result) throw new Error("JUNCTION_NOT_FOUND");
    return result;
  }

  sensorEvent(event: SensorEvent) {
    if (!this.junctions.exists(event.junction_id)) throw new Error("JUNCTION_NOT_FOUND");

    if (this.events.has(event.event_id)) {
      audit(event.junction_id, "DUPLICATE_EVENT", `Duplicate event ${event.event_id}`, event);
      return { accepted: false, reason: "DUPLICATE_EVENT" };
    }

    const engine = engineFor(event.junction_id);
    const result = engine.processSensorEvent(event);

    this.events.save(event);
    if (result.accepted) this.events.upsertVehicle(event);

    audit(
      event.junction_id,
      result.accepted ? "VEHICLE_EVENT_ACCEPTED" : "VEHICLE_EVENT_REJECTED",
      `${event.event_type} ${event.vehicle_id}: ${result.reason}`,
      event
    );

    if (result.accepted && result.requestedPhase) {
      this.requestPhase(event.junction_id, result.requestedPhase);
    }

    this.junctions.update(event.junction_id, {
      mode: engine.getState().mode,
      emergency_active: engine.getState().emergencyActive ? 1 : 0
    });

    return result;
  }

  requestPhase(junctionId: string, phase: Exclude<Phase, "ALL_RED">) {
    const engine = engineFor(junctionId);
    const transition = engine.requestPhase(phase);

    let pending: string | null = null;

    for (const step of transition) {
      const commandId = this.controller.sendPhase(junctionId, step);
      pending = commandId;
      audit(junctionId, "SIGNAL_REQUESTED", `Requested ${step}`, { command_id: commandId });
    }

    if (transition.length) {
      const finalPhase = transition[transition.length - 1];
      this.junctions.update(junctionId, {
        desired_phase: finalPhase,
        pending_command_id: pending
      });
    }

    return { transition, command_id: pending };
  }

  manual(junctionId: string, phase: Exclude<Phase, "ALL_RED">) {
    const engine = engineFor(junctionId);
    const transition = engine.manualPhase(phase);
    this.junctions.update(junctionId, { mode: "MANUAL" });
    audit(junctionId, "MANUAL_OVERRIDE", `Manual phase requested: ${phase}`);

    let commandId: string | null = null;
    for (const step of transition) {
      commandId = this.controller.sendPhase(junctionId, step);
      audit(junctionId, "SIGNAL_REQUESTED", `Requested ${step}`, { command_id: commandId });
    }

    if (commandId) {
      this.junctions.update(junctionId, {
        desired_phase: phase,
        pending_command_id: commandId
      });
    }

    return { transition, command_id: commandId };
  }

  returnAutomatic(junctionId: string) {
    const engine = engineFor(junctionId);
    engine.returnAutomatic();
    this.junctions.update(junctionId, { mode: engine.getState().mode });
    audit(junctionId, "RETURN_AUTOMATIC", "Returned to automatic mode");
    return this.status(junctionId);
  }

  history(junctionId: string, limit = 100) {\n    if (!this.junctions.exists(junctionId)) throw new Error("JUNCTION_NOT_FOUND");\n    return this.events.history(junctionId, limit);\n  }\n\n  controllerEvent(commandId: string, type: "ACK" | "NACK" | "TIMEOUT" | "OFFLINE" | "ONLINE") {
    const command: any = db.prepare("SELECT * FROM controller_commands WHERE command_id=?").get(commandId);
    if (!command) throw new Error("COMMAND_NOT_FOUND");

    if (type === "ACK") {
      db.prepare(`
        UPDATE controller_commands SET status='ACKED', acknowledged_at=?
        WHERE command_id=?
      `).run(new Date().toISOString(), commandId);

      this.junctions.update(command.junction_id, {
        actual_phase: command.requested_phase,
        current_phase: command.requested_phase,
        pending_command_id: null,
        controller_online: 1
      });

      audit(command.junction_id, "CONTROLLER_ACK", `Command ${commandId} acknowledged`);
    } else if (type === "NACK") {
      db.prepare("UPDATE controller_commands SET status='NACKED' WHERE command_id=?").run(commandId);
      this.junctions.update(command.junction_id, { controller_online: 0 });
      audit(command.junction_id, "CONTROLLER_FAILURE", `Command ${commandId} rejected`);
    } else if (type === "TIMEOUT") {
      db.prepare("UPDATE controller_commands SET status='TIMEOUT' WHERE command_id=?").run(commandId);
      this.junctions.update(command.junction_id, { mode: "DEGRADED", controller_online: 0 });
      audit(command.junction_id, "CONTROLLER_TIMEOUT", `Command ${commandId} timed out`);
    } else if (type === "OFFLINE") {
      this.junctions.update(command.junction_id, { mode: "DEGRADED", controller_online: 0 });
      audit(command.junction_id, "DEVICE_FAILURE", "Controller offline");
    } else {
      this.junctions.update(command.junction_id, { controller_online: 1 });
      audit(command.junction_id, "DEVICE_RECOVERED", "Controller online");
    }

    return this.status(command.junction_id);
  }
}
