import "dotenv/config";

export const env = {
  port: Number(process.env.PORT ?? 3000),
  dbFile: process.env.DB_FILE ?? "./data/factory-traffic.db",
  controllerAckTimeoutMs: Number(process.env.CONTROLLER_ACK_TIMEOUT_MS ?? 5000)
};
