import { randomUUID } from "node:crypto";
import { db } from "./database";

export interface ControllerPort {
  sendPhase(junctionId: string, phase: string): string;
}

export class RestControllerSimulator implements ControllerPort {
  sendPhase(junctionId: string, phase: string): string {
    const commandId = randomUUID();
    db.prepare(`
      INSERT INTO controller_commands(
        command_id,junction_id,command_type,requested_phase,status,created_at
      ) VALUES(?,?,?,?,?,?)
    `).run(commandId, junctionId, "REQUEST_PHASE", phase, "PENDING", new Date().toISOString());

    return commandId;
  }
}
