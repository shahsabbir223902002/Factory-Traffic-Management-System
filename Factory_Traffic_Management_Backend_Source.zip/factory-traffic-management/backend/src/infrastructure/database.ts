import Database from "better-sqlite3";
import fs from "node:fs";
import path from "node:path";
import { env } from "../config/env";

export const db = (() => {
  const filename = path.resolve(env.dbFile);
  fs.mkdirSync(path.dirname(filename), { recursive: true });
  return new Database(filename);
})();

db.pragma("journal_mode = WAL");

db.exec(`
CREATE TABLE IF NOT EXISTS junctions (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  mode TEXT NOT NULL DEFAULT 'AUTOMATIC',
  current_phase TEXT NOT NULL DEFAULT 'ALL_RED',
  desired_phase TEXT NOT NULL DEFAULT 'ALL_RED',
  actual_phase TEXT,
  controller_online INTEGER NOT NULL DEFAULT 1,
  emergency_active INTEGER NOT NULL DEFAULT 0,
  pending_command_id TEXT,
  updated_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS sensor_events (
  event_id TEXT PRIMARY KEY,
  junction_id TEXT NOT NULL,
  direction TEXT NOT NULL,
  event_type TEXT NOT NULL,
  vehicle_id TEXT NOT NULL,
  vehicle_type TEXT NOT NULL,
  sequence_no INTEGER NOT NULL,
  timestamp TEXT NOT NULL,
  received_at TEXT NOT NULL
);

CREATE TABLE IF NOT EXISTS vehicles (
  junction_id TEXT NOT NULL,
  vehicle_id TEXT NOT NULL,
  direction TEXT NOT NULL,
  vehicle_type TEXT NOT NULL,
  arrived_at TEXT NOT NULL,
  cleared_at TEXT,
  PRIMARY KEY (junction_id, vehicle_id)
);

CREATE TABLE IF NOT EXISTS controller_commands (
  command_id TEXT PRIMARY KEY,
  junction_id TEXT NOT NULL,
  command_type TEXT NOT NULL,
  requested_phase TEXT,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  acknowledged_at TEXT
);

CREATE TABLE IF NOT EXISTS audit_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  junction_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  message TEXT NOT NULL,
  metadata_json TEXT,
  created_at TEXT NOT NULL
);
`);

export function audit(junctionId: string, eventType: string, message: string, metadata?: unknown) {
  db.prepare(`
    INSERT INTO audit_history(junction_id,event_type,message,metadata_json,created_at)
    VALUES(?,?,?,?,?)
  `).run(junctionId, eventType, message, metadata ? JSON.stringify(metadata) : null, new Date().toISOString());
}
