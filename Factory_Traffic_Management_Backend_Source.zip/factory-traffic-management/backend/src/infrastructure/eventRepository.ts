import { db } from "./database";
import { SensorEvent } from "../domain/types";

export class EventRepository {
  has(eventId: string): boolean {
    return !!db.prepare("SELECT event_id FROM sensor_events WHERE event_id=?").get(eventId);
  }

  save(event: SensorEvent) {
    db.prepare(`
      INSERT INTO sensor_events(
        event_id,junction_id,direction,event_type,vehicle_id,vehicle_type,sequence_no,timestamp,received_at
      ) VALUES(?,?,?,?,?,?,?,?,?)
    `).run(
      event.event_id, event.junction_id, event.direction, event.event_type,
      event.vehicle_id, event.vehicle_type, event.sequence_no, event.timestamp,
      new Date().toISOString()
    );
  }

  upsertVehicle(event: SensorEvent) {
    if (event.event_type === "ARRIVAL") {
      db.prepare(`
        INSERT INTO vehicles(junction_id,vehicle_id,direction,vehicle_type,arrived_at)
        VALUES(?,?,?,?,?)
        ON CONFLICT(junction_id,vehicle_id) DO UPDATE SET
          direction=excluded.direction,
          vehicle_type=excluded.vehicle_type,
          arrived_at=excluded.arrived_at,
          cleared_at=NULL
      `).run(event.junction_id, event.vehicle_id, event.direction, event.vehicle_type, event.timestamp);
    } else {
      db.prepare(`
        UPDATE vehicles SET cleared_at=?
        WHERE junction_id=? AND vehicle_id=? AND cleared_at IS NULL
      `).run(event.timestamp, event.junction_id, event.vehicle_id);
    }
  }

  history(junctionId: string, limit = 100): any[] {
    return db.prepare(`
      SELECT * FROM audit_history
      WHERE junction_id=?
      ORDER BY id DESC LIMIT ?
    `).all(junctionId, limit);
  }
}
