import { db } from "./database";
import { JunctionStatus, Mode, Phase } from "../domain/types";

export class JunctionRepository {
  create(id: string, name: string) {
    const now = new Date().toISOString();
    db.prepare(`
      INSERT INTO junctions(id,name,mode,current_phase,desired_phase,actual_phase,updated_at)
      VALUES(?,?,?,?,?,?,?)
    `).run(id, name, "AUTOMATIC", "ALL_RED", "ALL_RED", null, now);
  }

  exists(id: string): boolean {
    return !!db.prepare("SELECT id FROM junctions WHERE id=?").get(id);
  }

  get(id: string): any {
    return db.prepare("SELECT * FROM junctions WHERE id=?").get(id);
  }

  list(): any[] {
    return db.prepare("SELECT * FROM junctions ORDER BY id").all();
  }

  update(id: string, patch: Partial<{
    mode: Mode;
    current_phase: Phase;
    desired_phase: Phase;
    actual_phase: Phase | null;
    controller_online: number;
    emergency_active: number;
    pending_command_id: string | null;
  }>) {
    const allowed = Object.entries(patch);
    if (!allowed.length) return;
    const set = allowed.map(([key]) => `${key}=@${key}`).join(",");
    db.prepare(`UPDATE junctions SET ${set}, updated_at=@updated_at WHERE id=@id`)
      .run({ ...patch, updated_at: new Date().toISOString(), id });
  }

  status(id: string): JunctionStatus | null {
    const j: any = this.get(id);
    if (!j) return null;

    const rows: any[] = db.prepare(`
      SELECT direction, COUNT(*) as count
      FROM vehicles
      WHERE junction_id=? AND cleared_at IS NULL
      GROUP BY direction
    `).all(id);

    const queues: any = { NORTH: 0, SOUTH: 0, EAST: 0, WEST: 0 };
    for (const row of rows) queues[row.direction] = row.count;

    return {
      id: j.id,
      name: j.name,
      mode: j.mode,
      current_phase: j.current_phase,
      desired_phase: j.desired_phase,
      actual_phase: j.actual_phase,
      controller_online: !!j.controller_online,
      emergency_active: !!j.emergency_active,
      queues,
      pending_command_id: j.pending_command_id
    };
  }
}
