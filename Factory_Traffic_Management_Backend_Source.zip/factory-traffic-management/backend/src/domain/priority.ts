import { VehicleType } from "./types";

export const VEHICLE_PRIORITY: Record<VehicleType, number> = {
  EMERGENCY: 100,
  TRUCK: 70,
  FORKLIFT: 40,
  EMPLOYEE_VEHICLE: 20
};

export function priorityOf(type: VehicleType): number {
  return VEHICLE_PRIORITY[type];
}
