import { Phase, Signal } from "./types";

export class TrafficStateMachine {
  static signalFor(phase: Phase): Record<"north"|"south"|"east"|"west", Signal> {
    if (phase === "NORTH_SOUTH") {
      return { north: "GREEN", south: "GREEN", east: "RED", west: "RED" };
    }
    if (phase === "EAST_WEST") {
      return { north: "RED", south: "RED", east: "GREEN", west: "GREEN" };
    }
    return { north: "RED", south: "RED", east: "RED", west: "RED" };
  }

  static transition(current: Phase, requested: Phase): Phase[] {
    if (current === requested) return [];
    if (current === "ALL_RED") return [requested];

    // Never go directly from one conflicting green phase to another.
    return [current === "NORTH_SOUTH" ? "NORTH_SOUTH" : "EAST_WEST", "ALL_RED", requested];
  }

  static isSafe(phase: Phase): boolean {
    const s = this.signalFor(phase);
    const nsGreen = s.north === "GREEN" || s.south === "GREEN";
    const ewGreen = s.east === "GREEN" || s.west === "GREEN";
    return !(nsGreen && ewGreen);
  }
}
