import { Phase, SensorEvent, Vehicle, Mode } from "./types";
import { TrafficStateMachine } from "./stateMachine";
import { TrafficScheduler } from "./scheduler";

export interface EngineResult {
  accepted: boolean;
  reason: string;
  requestedPhase?: Phase;
}

export class TrafficEngine {
  private vehicles = new Map<string, Vehicle>();
  private processedEvents = new Set<string>();
  private mode: Mode = "AUTOMATIC";
  private phase: Phase = "ALL_RED";
  private emergencyActive = false;
  private readonly scheduler = new TrafficScheduler();

  getState() {
    return {
      mode: this.mode,
      phase: this.phase,
      emergencyActive: this.emergencyActive,
      vehicles: [...this.vehicles.values()].filter(v => !v.cleared_at)
    };
  }

  setMode(mode: Mode) {
    this.mode = mode;
  }

  setPhase(phase: Phase) {
    if (!TrafficStateMachine.isSafe(phase)) {
      throw new Error("Unsafe phase");
    }
    this.phase = phase;
  }

  processSensorEvent(event: SensorEvent, now = new Date()): EngineResult {
    if (this.processedEvents.has(event.event_id)) {
      return { accepted: false, reason: "DUPLICATE_EVENT" };
    }

    if (!event.junction_id || !event.vehicle_id) {
      return { accepted: false, reason: "INVALID_EVENT" };
    }

    this.processedEvents.add(event.event_id);

    if (event.event_type === "ARRIVAL") {
      if (this.vehicles.has(event.vehicle_id) && !this.vehicles.get(event.vehicle_id)?.cleared_at) {
        return { accepted: false, reason: "VEHICLE_ALREADY_ACTIVE" };
      }

      const vehicle: Vehicle = {
        junction_id: event.junction_id,
        vehicle_id: event.vehicle_id,
        direction: event.direction,
        vehicle_type: event.vehicle_type,
        arrived_at: event.timestamp
      };

      this.vehicles.set(event.vehicle_id, vehicle);

      if (event.vehicle_type === "EMERGENCY") {
        this.emergencyActive = true;
        this.mode = "EMERGENCY";
      }

      const requested = this.scheduler.chooseNext({
        vehicles: [...this.vehicles.values()],
        now,
        currentPhase: this.phase
      }) ?? undefined;

      return {
        accepted: true,
        reason: "EVENT_ACCEPTED",
        requestedPhase: requested
      };
    }

    const vehicle = this.vehicles.get(event.vehicle_id);
    if (!vehicle || vehicle.cleared_at) {
      return { accepted: false, reason: "UNKNOWN_VEHICLE" };
    }

    vehicle.cleared_at = event.timestamp;

    if (vehicle.vehicle_type === "EMERGENCY") {
      this.emergencyActive = [...this.vehicles.values()].some(
        v => !v.cleared_at && v.vehicle_type === "EMERGENCY"
      );
      if (!this.emergencyActive && this.mode === "EMERGENCY") this.mode = "AUTOMATIC";
    }

    return { accepted: true, reason: "VEHICLE_CLEARED" };
  }

  requestPhase(requested: Exclude<Phase, "ALL_RED">): Phase[] {
    return TrafficStateMachine.transition(this.phase, requested);
  }

  manualPhase(requested: Exclude<Phase, "ALL_RED">): Phase[] {
    this.mode = "MANUAL";
    return this.requestPhase(requested);
  }

  returnAutomatic() {
    this.mode = this.emergencyActive ? "EMERGENCY" : "AUTOMATIC";
  }
}
