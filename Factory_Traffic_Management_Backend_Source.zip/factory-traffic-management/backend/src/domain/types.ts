export type Direction = "NORTH" | "SOUTH" | "EAST" | "WEST";
export type Phase = "NORTH_SOUTH" | "EAST_WEST" | "ALL_RED";
export type Signal = "RED" | "YELLOW" | "GREEN";
export type Mode = "AUTOMATIC" | "MANUAL" | "EMERGENCY" | "DEGRADED";
export type VehicleType = "FORKLIFT" | "TRUCK" | "EMPLOYEE_VEHICLE" | "EMERGENCY";
export type SensorEventType = "ARRIVAL" | "CLEAR";
export type ControllerEventType = "ACK" | "NACK" | "TIMEOUT" | "OFFLINE" | "ONLINE";
export type CommandType = "REQUEST_PHASE" | "RETURN_AUTOMATIC" | "EMERGENCY_CLEAR";

export interface SensorEvent {
  event_id: string;
  junction_id: string;
  direction: Direction;
  event_type: SensorEventType;
  vehicle_id: string;
  vehicle_type: VehicleType;
  sequence_no: number;
  timestamp: string;
}

export interface Vehicle {
  junction_id: string;
  vehicle_id: string;
  direction: Direction;
  vehicle_type: VehicleType;
  arrived_at: string;
  cleared_at?: string;
}

export interface SignalState {
  phase: Phase;
  north: Signal;
  south: Signal;
  east: Signal;
  west: Signal;
}

export interface JunctionStatus {
  id: string;
  name: string;
  mode: Mode;
  current_phase: Phase;
  desired_phase: Phase;
  actual_phase: Phase | null;
  controller_online: boolean;
  emergency_active: boolean;
  queues: Record<Direction, number>;
  pending_command_id: string | null;
}
