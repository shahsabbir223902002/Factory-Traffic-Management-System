import { Direction, Phase, Vehicle } from "./types";
import { priorityOf } from "./priority";

const directionsByPhase: Record<Exclude<Phase, "ALL_RED">, Direction[]> = {
  NORTH_SOUTH: ["NORTH", "SOUTH"],
  EAST_WEST: ["EAST", "WEST"]
};

export interface ScheduleInput {
  vehicles: Vehicle[];
  now: Date;
  currentPhase: Phase;
}

export class TrafficScheduler {
  chooseNext(input: ScheduleInput): Exclude<Phase, "ALL_RED"> | null {
    const candidates = (Object.keys(directionsByPhase) as Array<Exclude<Phase, "ALL_RED">>)
      .map(phase => {
        const score = directionsByPhase[phase].reduce((total, direction) => {
          const vehicles = input.vehicles.filter(v => v.direction === direction && !v.cleared_at);
          const queueSize = vehicles.length;
          const bestPriority = vehicles.reduce((max, v) => Math.max(max, priorityOf(v.vehicle_type)), 0);
          const waitingBonus = vehicles.reduce((sum, v) => {
            const seconds = Math.max(0, (input.now.getTime() - new Date(v.arrived_at).getTime()) / 1000);
            return sum + Math.min(seconds / 2, 50);
          }, 0);
          return total + queueSize * 10 + bestPriority + waitingBonus;
        }, 0);

        return { phase, score };
      })
      .sort((a, b) => b.score - a.score);

    const winner = candidates[0];
    if (!winner || winner.score <= 0) return null;
    return winner.phase;
  }
}
