import { describe, expect, it } from "vitest";
import { TrafficStateMachine } from "../src/domain/stateMachine";

describe("TrafficStateMachine", () => {
  it("never creates a conflicting green state", () => {
    expect(TrafficStateMachine.isSafe("NORTH_SOUTH")).toBe(true);
    expect(TrafficStateMachine.isSafe("EAST_WEST")).toBe(true);
    expect(TrafficStateMachine.isSafe("ALL_RED")).toBe(true);
  });

  it("uses ALL_RED when changing conflicting phases", () => {
    expect(TrafficStateMachine.transition("NORTH_SOUTH", "EAST_WEST"))
      .toEqual(["NORTH_SOUTH", "ALL_RED", "EAST_WEST"]);
  });

  it("does not add transitions when phase is unchanged", () => {
    expect(TrafficStateMachine.transition("EAST_WEST", "EAST_WEST")).toEqual([]);
  });
});
