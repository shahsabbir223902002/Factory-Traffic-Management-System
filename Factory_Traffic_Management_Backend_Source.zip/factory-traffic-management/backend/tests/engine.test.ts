import { describe, expect, it } from "vitest";
import { TrafficEngine } from "../src/domain/engine";

const event = (id: string, type: "ARRIVAL" | "CLEAR" = "ARRIVAL") => ({
  event_id: id,
  junction_id: "A",
  direction: "NORTH" as const,
  event_type: type,
  vehicle_id: "v1",
  vehicle_type: "TRUCK" as const,
  sequence_no: 1,
  timestamp: "2026-10-08T10:00:00.000Z"
});

describe("TrafficEngine", () => {
  it("is idempotent for duplicate event IDs", () => {
    const engine = new TrafficEngine();
    expect(engine.processSensorEvent(event("e1")).accepted).toBe(true);
    expect(engine.processSensorEvent(event("e1")).reason).toBe("DUPLICATE_EVENT");
    expect(engine.getState().vehicles).toHaveLength(1);
  });

  it("does not make queue negative for unknown clearance", () => {
    const engine = new TrafficEngine();
    const result = engine.processSensorEvent(event("clear-1", "CLEAR"));
    expect(result.accepted).toBe(false);
    expect(result.reason).toBe("UNKNOWN_VEHICLE");
  });

  it("enters emergency mode for an emergency arrival", () => {
    const engine = new TrafficEngine();
    const result = engine.processSensorEvent({
      ...event("em-1"),
      vehicle_id: "ambulance",
      vehicle_type: "EMERGENCY",
      direction: "EAST"
    });
    expect(result.accepted).toBe(true);
    expect(engine.getState().mode).toBe("EMERGENCY");
    expect(engine.getState().emergencyActive).toBe(true);
  });
});
