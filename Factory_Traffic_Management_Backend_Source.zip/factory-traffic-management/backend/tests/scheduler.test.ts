import { describe, expect, it } from "vitest";
import { TrafficScheduler } from "../src/domain/scheduler";

describe("TrafficScheduler", () => {
  it("prioritizes emergency traffic", () => {
    const scheduler = new TrafficScheduler();

    const phase = scheduler.chooseNext({
      currentPhase: "NORTH_SOUTH",
      now: new Date("2026-10-08T10:00:30.000Z"),
      vehicles: [
        {
          junction_id: "A",
          vehicle_id: "truck",
          direction: "NORTH",
          vehicle_type: "TRUCK",
          arrived_at: "2026-10-08T09:59:00.000Z"
        },
        {
          junction_id: "A",
          vehicle_id: "emergency",
          direction: "EAST",
          vehicle_type: "EMERGENCY",
          arrived_at: "2026-10-08T09:59:30.000Z"
        }
      ]
    });

    expect(phase).toBe("EAST_WEST");
  });
});
