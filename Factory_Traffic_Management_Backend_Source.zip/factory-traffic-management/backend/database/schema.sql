-- The runtime creates these tables automatically.
-- Kept here so the database design is explicit for assessment review.

CREATE TABLE junctions (
  id TEXT PRIMARY KEY,
  name TEXT NOT NULL,
  mode TEXT NOT NULL,
  current_phase TEXT NOT NULL,
  desired_phase TEXT NOT NULL,
  actual_phase TEXT,
  controller_online INTEGER NOT NULL,
  emergency_active INTEGER NOT NULL,
  pending_command_id TEXT,
  updated_at TEXT NOT NULL
);

CREATE TABLE sensor_events (
  event_id TEXT PRIMARY KEY,
  junction_id TEXT NOT NULL,
  direction TEXT NOT NULL,
  event_type TEXT NOT NULL,
  vehicle_id TEXT NOT NULL,
  vehicle_type TEXT NOT NULL,
  sequence_no INTEGER NOT NULL,
  timestamp TEXT NOT NULL,
  received_at TEXT NOT NULL
);

CREATE TABLE vehicles (
  junction_id TEXT NOT NULL,
  vehicle_id TEXT NOT NULL,
  direction TEXT NOT NULL,
  vehicle_type TEXT NOT NULL,
  arrived_at TEXT NOT NULL,
  cleared_at TEXT,
  PRIMARY KEY (junction_id, vehicle_id)
);

CREATE TABLE controller_commands (
  command_id TEXT PRIMARY KEY,
  junction_id TEXT NOT NULL,
  command_type TEXT NOT NULL,
  requested_phase TEXT,
  status TEXT NOT NULL,
  created_at TEXT NOT NULL,
  acknowledged_at TEXT
);

CREATE TABLE audit_history (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  junction_id TEXT NOT NULL,
  event_type TEXT NOT NULL,
  message TEXT NOT NULL,
  metadata_json TEXT,
  created_at TEXT NOT NULL
);
